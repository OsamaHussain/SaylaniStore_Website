import React, { useState } from 'react'

const User = () => {
    const [Login, setLogin] = useState()

  return (
    <div>User</div>
  )
}

export default User;